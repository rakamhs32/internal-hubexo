// import Swiper, { Navigation, Pagination } from 'swiper';
// // import styles bundle
// import 'swiper/css/bundle';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';

// export default {
//     init() {
//         document.querySelectorAll('.mySwiper').forEach(function(swiperContainer) {
//             var swiper = new Swiper(swiperContainer, {
//                 modules: [Navigation, Pagination],
//                 pagination: {
//                     el: '.swiper-pagination',
//                     dynamicBullets: true,
//                 },
//                 navigation: {
//                     nextEl: '.swiper-button-next',
//                     prevEl: '.swiper-button-prev',
//                 },
//             });
//         });
//     },
//     destroy() {},
// };
