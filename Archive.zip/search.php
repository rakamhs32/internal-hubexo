<?php
get_template_part('parts/shared/header');
?>


<?php
get_template_part('parts/shared/footer');
?>