<div class="content-panel yellow-bg centered-text-panel text-center">
    <div class="container snug-child fade-in">
        <?= get_field('text');?>
    </div>
</div>