<?php get_template_part('parts/shared/header'); ?>
<?php get_template_part('parts/news/banner'); ?>
<?php get_template_part('parts/news/post-list'); ?>
<?php get_template_part('parts/shared/footer');?>
<?php get_template_part('parts/shared/html-footer'); ?>