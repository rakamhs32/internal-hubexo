<div class="blog-content content-panel">
    <div class="container">
        <article class="single-post--content large-intro snug-child wysiwyg">
            <?= the_content(); ?>
        </article>
    </div>
</div>