<svg width="18" height="16" viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.625156 8L13.8846 8" stroke="currentcolor" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M10.4715 15.3846C10.4715 11.3231 13.4254 8 17.0356 8" stroke="currentcolor" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M10.4715 0.617187C10.4715 4.67873 13.4254 8.0018 17.0356 8.0018" stroke="currentcolor" stroke-width="1.84615" stroke-miterlimit="10"/>
</svg>
