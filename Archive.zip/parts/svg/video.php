<svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M19 10.5293C19 15.4999 14.9706 19.5293 10 19.5293C5.02944 19.5293 1 15.4999 1 10.5293C1 5.55873 5.02944 1.5293 10 1.5293C14.9706 1.5293 19 5.55873 19 10.5293Z" stroke="currentColor" stroke-width="2" />
  <path d="M8 10.5293V7.0293L11 8.8293L14 10.5293L11 12.2293L8 14.0293V10.5293Z" fill="currentColor" stroke="currentColor" stroke-miterlimit="10" />
</svg>