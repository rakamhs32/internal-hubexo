<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M2.46155 3.38473L4.3077 1.53857H11.6923L13.5385 3.38473V5.23088H2.46155V3.38473Z" stroke="#FAFAF0" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M13.5385 12.6154L11.6923 14.4616H4.3077L2.46155 12.6154V10.7693H13.5385V12.6154Z" stroke="#FAFAF0" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M0.615387 8H15.3846" stroke="#FAFAF0" stroke-width="1.84615" stroke-miterlimit="10"/>
</svg>
