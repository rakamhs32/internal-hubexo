<svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 0.953193L8 15.8701" stroke="#321432" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M0.615385 12.0304C4.67692 12.0304 8 15.3535 8 19.415" stroke="#321432" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M15.3828 12.0304C11.3213 12.0304 7.9982 15.3535 7.9982 19.415" stroke="#321432" stroke-width="1.84615" stroke-miterlimit="10"/>
</svg>