<svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 19.0468L8 4.12988" stroke="#321432" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M15.3846 7.96958C11.3231 7.96958 8 4.6465 8 0.584961" stroke="#321432" stroke-width="1.84615" stroke-miterlimit="10"/>
<path d="M0.617187 7.96958C4.67873 7.96958 8.0018 4.6465 8.0018 0.584961" stroke="#321432" stroke-width="1.84615" stroke-miterlimit="10"/>
</svg>