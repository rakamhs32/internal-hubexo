<svg id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32.25 32.25">
  <defs>
    <style>
      .cls-1 {
        fill: none;
        stroke: #321432;
        stroke-miterlimit: 10;
        stroke-width: 2.46px;
      }
    </style>
  </defs>
  <path class="cls-1" d="M16.13,22.25c0-6.1,4.95-11.05,11.05-11.05"/>
  <path class="cls-1" d="M5.08,11.2c6.1,0,11.05,4.95,11.05,11.05"/>
</svg>