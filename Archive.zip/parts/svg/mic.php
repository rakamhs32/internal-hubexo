<svg width="46" height="58" viewBox="0 0 46 58" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M43 28C43 39 34 48 23 48C12 48 3 39 3 28" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M23 57.9992V45.6992" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M23 38.0996C17.5 38.0996 13 33.5996 13 28.0996V13.0996C13 7.59961 17.5 3.09961 23 3.09961C28.5 3.09961 33 7.59961 33 13.0996V28.0996C33 33.5996 28.5 38.0996 23 38.0996Z" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M25.5 20.5H33" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M13 20.5H20.5" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M13 28H20.4" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M13 13H20.4" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M25.5 28H33" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
    <path d="M25.5 13H33" stroke="#DCFF3C" stroke-width="5" stroke-miterlimit="10"/>
</svg>