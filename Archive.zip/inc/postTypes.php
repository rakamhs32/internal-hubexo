<?php

// namespace EightArms;

// function createPostTypes()
// {
//   register_post_type('work', [
//     'labels' => [
//       'name' => __('Work'),
//       'singular_name' => __('Work')
//     ],
//     'public' => true,
//     'has_archive' => true,
//     //'taxonomies' => ['discipline'],
//     'supports' => ['title', 'editor', 'thumbnail'],
//     'rewrite' => array('slug' => 'projects','with_front' => false),
//   ]);
// }
// add_action('init', 'EightArms\createPostTypes');