<?php

global $responsiveImageSizes;

add_theme_support('custom-header');
add_theme_support('post-thumbnails');

add_image_size('mobile', 600, 0, false);