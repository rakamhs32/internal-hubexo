<?php

register_nav_menus(
  array(
    'main' => __('Main navigation'),
    'footer' => __('Footer navigation'),
    'footer-addon' => __('Footer addon navigation'),
  )
);